#!/bin/bash
cd /home/container/app
echo "Iniciando Servidor de Propostas Comerciais..."
python app.py