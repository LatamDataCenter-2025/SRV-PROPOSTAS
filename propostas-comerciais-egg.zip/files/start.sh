#!/bin/bash
bash entrypoint.sh